using System.Text.Json;
using System.Text.Json.Serialization;

namespace MiStreamer;

public enum EncoderMode
{
    IntelQsv,
    CpuX264
}

public enum OverlayPosition
{
    TopLeft,
    TopRight
}

public sealed class StreamerConfig
{
    public string TikTokRtmpUrl { get; set; } = "";
    public string TikTokStreamKey { get; set; } = "";

    public string YouTubeRtmpUrl { get; set; } = "rtmp://a.rtmp.youtube.com/live2";
    public string YouTubeStreamKey { get; set; } = "";

    public string TikTokUsername { get; set; } = "";

    [JsonConverter(typeof(JsonStringEnumConverter))]
    public EncoderMode Encoder { get; set; } = EncoderMode.IntelQsv;

    [JsonConverter(typeof(JsonStringEnumConverter))]
    public OverlayPosition OverlayPosition { get; set; } = OverlayPosition.TopLeft;

    public int SecondsPerCoin { get; set; } = 15;

    public Dictionary<string, int> GiftRules { get; set; } =
        new(StringComparer.OrdinalIgnoreCase)
        {
            ["Rose"] = 30,
            ["Rosa"] = 30,
            ["Mini Donut"] = 180,
            ["Lion"] = 1800,
            ["León"] = 1800
        };

    public static StreamerConfig Load()
    {
        try
        {
            if (!File.Exists(AppFiles.ConfigPath))
            {
                var created = new StreamerConfig();
                created.Save();
                return created;
            }

            var json = File.ReadAllText(AppFiles.ConfigPath);
            var config = JsonSerializer.Deserialize<StreamerConfig>(json, JsonOptions()) ?? new StreamerConfig();

            config.GiftRules = new Dictionary<string, int>(
                config.GiftRules ?? new Dictionary<string, int>(),
                StringComparer.OrdinalIgnoreCase);

            return config;
        }
        catch
        {
            return new StreamerConfig();
        }
    }

    public void Save()
    {
        Directory.CreateDirectory(AppFiles.BaseDirectory);
        var temp = AppFiles.ConfigPath + ".tmp";
        File.WriteAllText(temp, JsonSerializer.Serialize(this, JsonOptions()));
        File.Move(temp, AppFiles.ConfigPath, true);
    }

    private static JsonSerializerOptions JsonOptions() => new()
    {
        WriteIndented = true,
        PropertyNameCaseInsensitive = true,
        Converters = { new JsonStringEnumConverter() }
    };
}

public static class AppFiles
{
    public static string BaseDirectory => AppContext.BaseDirectory;
    public static string ConfigPath => Path.Combine(BaseDirectory, "config.json");
    public static string TimePath => Path.Combine(BaseDirectory, "tiempo_extensible.txt");
    public static string FfmpegPath => Path.Combine(BaseDirectory, "ffmpeg.exe");
}
