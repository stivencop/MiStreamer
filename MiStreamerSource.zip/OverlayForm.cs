using System.Drawing.Drawing2D;
using System.Runtime.InteropServices;

namespace MiStreamer;

public sealed class OverlayForm : Form
{
    private const int GwlExStyle = -20;
    private const long WsExTransparent = 0x00000020L;
    private const long WsExLayered = 0x00080000L;
    private const long WsExToolWindow = 0x00000080L;
    private const long WsExNoActivate = 0x08000000L;

    private const int WmNcHitTest = 0x0084;
    private const int HtTransparent = -1;

    private readonly object _sync = new();
    private readonly List<string> _chat = new();
    private readonly System.Windows.Forms.Timer _animationTimer;

    private string _time = "00:00:00";
    private string _giftText = "";
    private DateTime _giftUntilUtc = DateTime.MinValue;

    public OverlayForm()
    {
        FormBorderStyle = FormBorderStyle.None;
        TopMost = true;
        ShowInTaskbar = false;
        StartPosition = FormStartPosition.Manual;
        DoubleBuffered = true;

        BackColor = Color.FromArgb(1, 2, 3);
        TransparencyKey = BackColor;

        Width = 650;
        Height = 390;

        _animationTimer = new System.Windows.Forms.Timer
        {
            Interval = 100
        };
        _animationTimer.Tick += (_, _) =>
        {
            if (_giftUntilUtc != DateTime.MinValue && DateTime.UtcNow >= _giftUntilUtc)
            {
                lock (_sync)
                {
                    _giftText = "";
                    _giftUntilUtc = DateTime.MinValue;
                }
            }

            Invalidate();
        };
        _animationTimer.Start();
    }

    protected override bool ShowWithoutActivation => true;

    protected override CreateParams CreateParams
    {
        get
        {
            var cp = base.CreateParams;
            cp.ExStyle |= (int)(WsExTransparent | WsExLayered | WsExToolWindow | WsExNoActivate);
            return cp;
        }
    }

    protected override void OnHandleCreated(EventArgs e)
    {
        base.OnHandleCreated(e);

        var style = GetWindowLongPtr(Handle, GwlExStyle).ToInt64();
        style |= WsExTransparent | WsExLayered | WsExToolWindow | WsExNoActivate;
        SetWindowLongPtr(Handle, GwlExStyle, new IntPtr(style));
    }

    protected override void WndProc(ref Message m)
    {
        if (m.Msg == WmNcHitTest)
        {
            m.Result = new IntPtr(HtTransparent);
            return;
        }

        base.WndProc(ref m);
    }

    public void SetTime(TimeSpan remaining)
    {
        var totalHours = (long)Math.Floor(remaining.TotalHours);
        var minutes = remaining.Minutes;
        var seconds = remaining.Seconds;

        lock (_sync)
            _time = $"{totalHours:00}:{minutes:00}:{seconds:00}";

        Invalidate();
    }

    public void AddChat(string username, string message)
    {
        lock (_sync)
        {
            _chat.Add($"{username}: {message}");
            while (_chat.Count > 7)
                _chat.RemoveAt(0);
        }

        Invalidate();
    }

    public void ShowGift(string text)
    {
        lock (_sync)
        {
            _giftText = text;
            _giftUntilUtc = DateTime.UtcNow.AddSeconds(6);
        }

        Invalidate();
    }

    public void ApplyPosition(OverlayPosition position)
    {
        var area = Screen.PrimaryScreen?.Bounds ?? new Rectangle(0, 0, 1920, 1080);
        const int margin = 24;

        Location = position == OverlayPosition.TopRight
            ? new Point(area.Right - Width - margin, area.Top + margin)
            : new Point(area.Left + margin, area.Top + margin);
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);

        e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
        e.Graphics.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;

        string time;
        string gift;
        List<string> chat;

        lock (_sync)
        {
            time = _time;
            gift = _giftText;
            chat = _chat.ToList();
        }

        DrawTimer(e.Graphics, time);

        var y = 110;
        if (!string.IsNullOrWhiteSpace(gift))
        {
            using var giftBg = new SolidBrush(Color.FromArgb(205, 95, 55, 0));
            using var giftFont = new Font("Segoe UI", 15, FontStyle.Bold);
            using var giftBrush = new SolidBrush(Color.White);

            var giftRect = new RectangleF(4, y, Width - 8, 54);
            e.Graphics.FillRoundedRectangle(giftBg, giftRect, 12);
            e.Graphics.DrawString(gift, giftFont, giftBrush, new RectangleF(18, y + 11, Width - 36, 34));
            y += 65;
        }

        if (chat.Count > 0)
        {
            var boxHeight = Math.Min(205, 22 + chat.Count * 25);
            using var bg = new SolidBrush(Color.FromArgb(165, 0, 0, 0));
            e.Graphics.FillRoundedRectangle(bg, new RectangleF(4, y, Width - 8, boxHeight), 14);

            using var chatFont = new Font("Segoe UI", 12, FontStyle.Regular);
            using var chatBrush = new SolidBrush(Color.White);

            var lineY = y + 12;
            foreach (var line in chat)
            {
                var shown = line.Length > 78 ? line[..75] + "..." : line;
                e.Graphics.DrawString(shown, chatFont, chatBrush, 18, lineY);
                lineY += 25;
            }
        }
    }

    private static void DrawTimer(Graphics g, string text)
    {
        using var path = new GraphicsPath();
        using var font = new Font("Segoe UI", 39, FontStyle.Bold, GraphicsUnit.Pixel);

        path.AddString(
            text,
            font.FontFamily,
            (int)font.Style,
            52,
            new PointF(8, 12),
            StringFormat.GenericDefault);

        using var outline = new Pen(Color.Black, 8)
        {
            LineJoin = LineJoin.Round
        };
        using var fill = new SolidBrush(Color.White);

        g.DrawPath(outline, path);
        g.FillPath(fill, path);
    }

    [DllImport("user32.dll", EntryPoint = "GetWindowLongPtrW")]
    private static extern IntPtr GetWindowLongPtr(IntPtr hWnd, int nIndex);

    [DllImport("user32.dll", EntryPoint = "SetWindowLongPtrW")]
    private static extern IntPtr SetWindowLongPtr(IntPtr hWnd, int nIndex, IntPtr dwNewLong);
}

internal static class GraphicsExtensions
{
    public static void FillRoundedRectangle(this Graphics graphics, Brush brush, RectangleF rect, float radius)
    {
        using var path = new GraphicsPath();

        var d = radius * 2;
        path.AddArc(rect.X, rect.Y, d, d, 180, 90);
        path.AddArc(rect.Right - d, rect.Y, d, d, 270, 90);
        path.AddArc(rect.Right - d, rect.Bottom - d, d, d, 0, 90);
        path.AddArc(rect.X, rect.Bottom - d, d, d, 90, 90);
        path.CloseFigure();

        graphics.FillPath(brush, path);
    }
}
