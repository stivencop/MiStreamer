using System.Diagnostics;
using System.Globalization;

namespace MiStreamer;

public sealed class ExtensibleClock
{
    private readonly object _sync = new();
    private readonly Stopwatch _stopwatch = new();

    private TimeSpan _baseRemaining = TimeSpan.Zero;
    private bool _paused = true;

    public bool IsPaused
    {
        get
        {
            lock (_sync)
                return _paused;
        }
    }

    public TimeSpan Remaining
    {
        get
        {
            lock (_sync)
                return RemainingUnsafe();
        }
    }

    public void Load()
    {
        lock (_sync)
        {
            if (!File.Exists(AppFiles.TimePath))
                return;

            var raw = File.ReadAllText(AppFiles.TimePath).Trim();

            if (long.TryParse(raw, NumberStyles.Integer, CultureInfo.InvariantCulture, out var seconds))
                _baseRemaining = TimeSpan.FromSeconds(Math.Max(0, seconds));
            else if (TimeSpan.TryParse(raw, CultureInfo.InvariantCulture, out var parsed))
                _baseRemaining = parsed < TimeSpan.Zero ? TimeSpan.Zero : parsed;

            _paused = true;
            _stopwatch.Reset();
        }
    }

    public void Save()
    {
        var seconds = (long)Math.Ceiling(Remaining.TotalSeconds);
        File.WriteAllText(
            AppFiles.TimePath,
            Math.Max(0, seconds).ToString(CultureInfo.InvariantCulture));
    }

    public void Add(TimeSpan amount)
    {
        lock (_sync)
        {
            var current = RemainingUnsafe();
            var next = current + amount;
            if (next < TimeSpan.Zero)
                next = TimeSpan.Zero;

            _baseRemaining = next;

            if (!_paused)
                _stopwatch.Restart();
        }
    }

    public void Set(TimeSpan value)
    {
        lock (_sync)
        {
            _baseRemaining = value < TimeSpan.Zero ? TimeSpan.Zero : value;
            if (!_paused)
                _stopwatch.Restart();
        }
    }

    public void Pause()
    {
        lock (_sync)
        {
            if (_paused)
                return;

            _baseRemaining = RemainingUnsafe();
            _stopwatch.Reset();
            _paused = true;
        }
    }

    public void Resume()
    {
        lock (_sync)
        {
            if (!_paused)
                return;

            _paused = false;
            _stopwatch.Restart();
        }
    }

    public void TogglePause()
    {
        if (IsPaused)
            Resume();
        else
            Pause();
    }

    private TimeSpan RemainingUnsafe()
    {
        var remaining = _paused
            ? _baseRemaining
            : _baseRemaining - _stopwatch.Elapsed;

        return remaining > TimeSpan.Zero ? remaining : TimeSpan.Zero;
    }
}
