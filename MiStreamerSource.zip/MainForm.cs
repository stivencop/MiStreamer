using System.Diagnostics;

namespace MiStreamer;

public sealed class MainForm : Form
{
    private readonly StreamerConfig _config;
    private readonly ExtensibleClock _clock = new();
    private readonly OverlayForm _overlay = new();
    private readonly StreamingService _streaming = new();
    private readonly TikTokService _tikTok = new();

    private CancellationTokenSource? _tikTokCts;
    private Task? _tikTokTask;

    private readonly System.Windows.Forms.Timer _uiTimer = new();
    private readonly System.Windows.Forms.Timer _saveTimer = new();
    private readonly System.Windows.Forms.Timer _configDebounce = new();

    private readonly TextBox _txtTikTokUrl = new();
    private readonly TextBox _txtTikTokKey = new();
    private readonly TextBox _txtYouTubeUrl = new();
    private readonly TextBox _txtYouTubeKey = new();
    private readonly TextBox _txtTikTokUser = new();

    private readonly ComboBox _cmbEncoder = new();
    private readonly ComboBox _cmbOverlayPosition = new();

    private readonly NumericUpDown _numSecondsPerCoin = new();
    private readonly DataGridView _giftRules = new();

    private readonly Label _lblTime = new();
    private readonly Label _lblStream = new();
    private readonly Label _lblTikTok = new();
    private readonly Label _lblMetrics = new();

    private readonly ListBox _chat = new();
    private readonly ListBox _logs = new();

    private readonly Button _btnOverlay = new();
    private readonly Button _btnPause = new();
    private readonly Button _btnStream = new();
    private readonly Button _btnTikTok = new();

    private bool _overlayVisible;

    public MainForm()
    {
        Text = "MiStreamer - Panel de Control";
        StartPosition = FormStartPosition.CenterScreen;
        MinimumSize = new Size(980, 720);
        Size = new Size(1100, 790);

        _config = StreamerConfig.Load();
        _clock.Load();

        BuildUi();
        LoadConfigIntoUi();
        WireEvents();

        _overlay.ApplyPosition(_config.OverlayPosition);

        _uiTimer.Interval = 250;
        _uiTimer.Tick += UiTimerOnTick;
        _uiTimer.Start();

        _saveTimer.Interval = 2000;
        _saveTimer.Tick += (_, _) =>
        {
            try { _clock.Save(); } catch { }
        };
        _saveTimer.Start();

        _configDebounce.Interval = 700;
        _configDebounce.Tick += (_, _) =>
        {
            _configDebounce.Stop();
            SaveUiToConfig();
        };
    }

    private void BuildUi()
    {
        var tabs = new TabControl
        {
            Dock = DockStyle.Fill
        };

        tabs.TabPages.Add(BuildStreamTab());
        tabs.TabPages.Add(BuildExtensibleTab());
        tabs.TabPages.Add(BuildTikTokTab());
        tabs.TabPages.Add(BuildLogsTab());

        Controls.Add(tabs);
    }

    private TabPage BuildStreamTab()
    {
        var tab = new TabPage("Streaming");
        var panel = NewTable(2, 11);
        tab.Controls.Add(panel);

        var row = 0;

        AddRow(panel, row++, "TikTok RTMP URL", _txtTikTokUrl);
        AddRow(panel, row++, "TikTok Stream Key", _txtTikTokKey);
        AddRow(panel, row++, "YouTube RTMP URL", _txtYouTubeUrl);
        AddRow(panel, row++, "YouTube Stream Key", _txtYouTubeKey);

        _txtTikTokKey.UseSystemPasswordChar = true;
        _txtYouTubeKey.UseSystemPasswordChar = true;

        _cmbEncoder.DropDownStyle = ComboBoxStyle.DropDownList;
        _cmbEncoder.Items.AddRange(new object[]
        {
            "Intel QSV (h264_qsv)",
            "CPU x264 (ultrafast / 2 threads)"
        });
        AddRow(panel, row++, "Encoder", _cmbEncoder);

        _cmbOverlayPosition.DropDownStyle = ComboBoxStyle.DropDownList;
        _cmbOverlayPosition.Items.AddRange(new object[]
        {
            "Arriba - Izquierda",
            "Arriba - Derecha"
        });
        AddRow(panel, row++, "Posición Overlay", _cmbOverlayPosition);

        _btnOverlay.Text = "Mostrar Overlay";
        _btnOverlay.AutoSize = true;

        _btnStream.Text = "Iniciar Streaming";
        _btnStream.AutoSize = true;

        var buttons = new FlowLayoutPanel
        {
            Dock = DockStyle.Fill,
            AutoSize = true,
            FlowDirection = FlowDirection.LeftToRight
        };
        buttons.Controls.Add(_btnStream);
        buttons.Controls.Add(_btnOverlay);

        panel.Controls.Add(buttons, 1, row++);
        panel.Controls.Add(_lblStream, 1, row++);
        panel.Controls.Add(_lblMetrics, 1, row++);

        var note = new Label
        {
            Text = "Salida: 720x1280, 30 FPS. El audio del sistema se captura mediante WASAPI Loopback en C# y se entrega a FFmpeg por pipe.",
            Dock = DockStyle.Fill,
            AutoSize = true,
            MaximumSize = new Size(780, 0)
        };
        panel.Controls.Add(note, 1, row++);

        return tab;
    }

    private TabPage BuildExtensibleTab()
    {
        var tab = new TabPage("Extensible");
        var root = new FlowLayoutPanel
        {
            Dock = DockStyle.Fill,
            FlowDirection = FlowDirection.TopDown,
            Padding = new Padding(24),
            AutoScroll = true,
            WrapContents = false
        };

        _lblTime.Font = new Font("Segoe UI", 34, FontStyle.Bold);
        _lblTime.AutoSize = true;
        _lblTime.Text = "00:00:00";
        root.Controls.Add(_lblTime);

        var buttons = new FlowLayoutPanel
        {
            AutoSize = true,
            FlowDirection = FlowDirection.LeftToRight
        };

        buttons.Controls.Add(TimeButton("+1m", TimeSpan.FromMinutes(1)));
        buttons.Controls.Add(TimeButton("+5m", TimeSpan.FromMinutes(5)));
        buttons.Controls.Add(TimeButton("+10m", TimeSpan.FromMinutes(10)));
        buttons.Controls.Add(TimeButton("-1m", TimeSpan.FromMinutes(-1)));

        _btnPause.Text = "Reanudar";
        _btnPause.AutoSize = true;
        buttons.Controls.Add(_btnPause);

        root.Controls.Add(buttons);

        var info = new Label
        {
            AutoSize = true,
            MaximumSize = new Size(850, 0),
            Text = "El tiempo se guarda automáticamente en tiempo_extensible.txt. " +
                   "El cálculo usa Stopwatch para no depender de la frecuencia del Timer visual."
        };
        root.Controls.Add(info);

        tab.Controls.Add(root);
        return tab;
    }

    private TabPage BuildTikTokTab()
    {
        var tab = new TabPage("TikTok / Regalos");

        var split = new SplitContainer
        {
            Dock = DockStyle.Fill,
            Orientation = Orientation.Vertical,
            SplitterDistance = 540
        };

        var left = NewTable(2, 6);

        AddRow(left, 0, "Usuario TikTok", _txtTikTokUser);

        _btnTikTok.Text = "Conectar TikTok";
        _btnTikTok.AutoSize = true;
        left.Controls.Add(_btnTikTok, 1, 1);

        _lblTikTok.Text = "TikTok: desconectado";
        _lblTikTok.AutoSize = true;
        left.Controls.Add(_lblTikTok, 1, 2);

        _numSecondsPerCoin.Minimum = 0;
        _numSecondsPerCoin.Maximum = 3600;
        _numSecondsPerCoin.Width = 120;
        AddRow(left, 3, "Segundos por moneda", _numSecondsPerCoin);

        var rulesLabel = new Label
        {
            Text = "Reglas especiales (segundos por unidad de regalo):",
            AutoSize = true,
            Dock = DockStyle.Fill
        };
        left.Controls.Add(rulesLabel, 0, 4);
        left.SetColumnSpan(rulesLabel, 2);

        _giftRules.Dock = DockStyle.Fill;
        _giftRules.AllowUserToAddRows = true;
        _giftRules.AllowUserToDeleteRows = true;
        _giftRules.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        _giftRules.Columns.Add("Gift", "Regalo");
        _giftRules.Columns.Add("Seconds", "Segundos");
        left.Controls.Add(_giftRules, 0, 5);
        left.SetColumnSpan(_giftRules, 2);

        split.Panel1.Controls.Add(left);

        var right = new Panel { Dock = DockStyle.Fill };
        var chatTitle = new Label
        {
            Text = "Últimos comentarios",
            Dock = DockStyle.Top,
            Height = 28,
            Font = new Font("Segoe UI", 10, FontStyle.Bold)
        };
        _chat.Dock = DockStyle.Fill;

        right.Controls.Add(_chat);
        right.Controls.Add(chatTitle);
        split.Panel2.Controls.Add(right);

        tab.Controls.Add(split);
        return tab;
    }

    private TabPage BuildLogsTab()
    {
        var tab = new TabPage("Logs");
        _logs.Dock = DockStyle.Fill;
        tab.Controls.Add(_logs);
        return tab;
    }

    private static TableLayoutPanel NewTable(int columns, int rows)
    {
        var panel = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            Padding = new Padding(18),
            ColumnCount = columns,
            RowCount = rows,
            AutoScroll = true
        };

        panel.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 190));
        panel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));

        for (var i = 0; i < rows; i++)
            panel.RowStyles.Add(new RowStyle(SizeType.AutoSize));

        return panel;
    }

    private static void AddRow(TableLayoutPanel panel, int row, string label, Control control)
    {
        var l = new Label
        {
            Text = label,
            AutoSize = true,
            Anchor = AnchorStyles.Left,
            Margin = new Padding(3, 8, 3, 8)
        };

        control.Dock = DockStyle.Top;
        control.Margin = new Padding(3, 5, 3, 5);

        panel.Controls.Add(l, 0, row);
        panel.Controls.Add(control, 1, row);
    }

    private Button TimeButton(string text, TimeSpan delta)
    {
        var button = new Button
        {
            Text = text,
            AutoSize = true
        };

        button.Click += (_, _) => _clock.Add(delta);
        return button;
    }

    private void LoadConfigIntoUi()
    {
        _txtTikTokUrl.Text = _config.TikTokRtmpUrl;
        _txtTikTokKey.Text = _config.TikTokStreamKey;
        _txtYouTubeUrl.Text = _config.YouTubeRtmpUrl;
        _txtYouTubeKey.Text = _config.YouTubeStreamKey;
        _txtTikTokUser.Text = _config.TikTokUsername;

        _cmbEncoder.SelectedIndex = _config.Encoder == EncoderMode.IntelQsv ? 0 : 1;
        _cmbOverlayPosition.SelectedIndex = _config.OverlayPosition == OverlayPosition.TopLeft ? 0 : 1;

        _numSecondsPerCoin.Value = Math.Clamp(_config.SecondsPerCoin, 0, 3600);

        _giftRules.Rows.Clear();
        foreach (var pair in _config.GiftRules.OrderBy(x => x.Key))
            _giftRules.Rows.Add(pair.Key, pair.Value);
    }

    private void WireEvents()
    {
        _btnPause.Click += (_, _) =>
        {
            _clock.TogglePause();
            RefreshPauseButton();
        };

        _btnOverlay.Click += (_, _) => ToggleOverlay();
        _btnStream.Click += async (_, _) => await ToggleStreamingAsync();
        _btnTikTok.Click += (_, _) => ToggleTikTok();

        _cmbOverlayPosition.SelectedIndexChanged += (_, _) =>
        {
            var position = _cmbOverlayPosition.SelectedIndex == 1
                ? OverlayPosition.TopRight
                : OverlayPosition.TopLeft;

            _overlay.ApplyPosition(position);
            MarkConfigDirty();
        };

        _streaming.Log += AppendLog;
        _tikTok.Log += AppendLog;
        _tikTok.Connected += () => SafeUi(() =>
        {
            _lblTikTok.Text = "TikTok: conectado";
            _btnTikTok.Text = "Desconectar TikTok";
        });
        _tikTok.Disconnected += () => SafeUi(() =>
        {
            _lblTikTok.Text = "TikTok: desconectado";
            _btnTikTok.Text = "Conectar TikTok";
        });
        _tikTok.ChatReceived += (user, message) => SafeUi(() =>
        {
            var line = $"{user}: {message}";
            _chat.Items.Insert(0, line);
            while (_chat.Items.Count > 100)
                _chat.Items.RemoveAt(_chat.Items.Count - 1);

            _overlay.AddChat(user, message);
        });
        _tikTok.GiftReceived += gift => SafeUi(() => ProcessGift(gift));

        foreach (var tb in new[]
                 {
                     _txtTikTokUrl, _txtTikTokKey, _txtYouTubeUrl,
                     _txtYouTubeKey, _txtTikTokUser
                 })
        {
            tb.TextChanged += (_, _) => MarkConfigDirty();
        }

        _cmbEncoder.SelectedIndexChanged += (_, _) => MarkConfigDirty();
        _numSecondsPerCoin.ValueChanged += (_, _) => MarkConfigDirty();
        _giftRules.CellValueChanged += (_, _) => MarkConfigDirty();
        _giftRules.RowsRemoved += (_, _) => MarkConfigDirty();
        _giftRules.UserAddedRow += (_, _) => MarkConfigDirty();

        FormClosing += MainFormOnFormClosing;

        RefreshPauseButton();
    }

    private void UiTimerOnTick(object? sender, EventArgs e)
    {
        var remaining = _clock.Remaining;
        var totalHours = (long)Math.Floor(remaining.TotalHours);

        _lblTime.Text = $"{totalHours:00}:{remaining.Minutes:00}:{remaining.Seconds:00}";
        _overlay.SetTime(remaining);
        _lblMetrics.Text = _streaming.GetMetrics();

        if (remaining == TimeSpan.Zero && !_clock.IsPaused)
        {
            _clock.Pause();
            RefreshPauseButton();
        }
    }

    private async Task ToggleStreamingAsync()
    {
        if (_streaming.IsRunning)
        {
            _btnStream.Enabled = false;

            try
            {
                await _streaming.StopAsync();
                _btnStream.Text = "Iniciar Streaming";
                _lblStream.Text = "Streaming: detenido";
            }
            finally
            {
                _btnStream.Enabled = true;
            }

            return;
        }

        SaveUiToConfig();
        _btnStream.Enabled = false;

        try
        {
            await _streaming.StartAsync(_config);
            _btnStream.Text = "Detener Streaming";
            _lblStream.Text = "Streaming: EN VIVO";
        }
        catch (Exception ex)
        {
            MessageBox.Show(
                this,
                ex.Message,
                "No fue posible iniciar el streaming",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error);

            AppendLog("Streaming ERROR: " + ex);
        }
        finally
        {
            _btnStream.Enabled = true;
        }
    }

    private void ToggleTikTok()
    {
        if (_tikTokCts is not null)
        {
            _btnTikTok.Enabled = false;
            _tikTokCts.Cancel();
            _lblTikTok.Text = "TikTok: desconectando...";
            return;
        }

        SaveUiToConfig();

        if (string.IsNullOrWhiteSpace(_config.TikTokUsername))
        {
            MessageBox.Show(this, "Escribe el @usuario de TikTok.", "TikTok");
            return;
        }

        _tikTokCts = new CancellationTokenSource();
        var token = _tikTokCts.Token;

        _lblTikTok.Text = "TikTok: conectando...";
        _btnTikTok.Text = "Desconectar TikTok";

        _tikTokTask = _tikTok.RunAsync(_config.TikTokUsername, token);
        _ = ObserveTikTokTaskAsync(_tikTokTask);
    }

    private async Task ObserveTikTokTaskAsync(Task task)
    {
        try
        {
            await task;
        }
        catch (Exception ex)
        {
            AppendLog("TikTok ERROR: " + ex);
            SafeUi(() => MessageBox.Show(
                this,
                ex.Message,
                "Error de TikTok LIVE",
                MessageBoxButtons.OK,
                MessageBoxIcon.Warning));
        }
        finally
        {
            SafeUi(() =>
            {
                _tikTokCts?.Dispose();
                _tikTokCts = null;
                _lblTikTok.Text = "TikTok: desconectado";
                _btnTikTok.Text = "Conectar TikTok";
                _btnTikTok.Enabled = true;
            });
        }
    }

    private void ProcessGift(TikTokGift gift)
    {
        var amount = Math.Max(1L, gift.Amount);

        long seconds;

        if (_config.GiftRules.TryGetValue(gift.GiftName, out var fixedSeconds))
        {
            seconds = fixedSeconds * amount;
        }
        else
        {
            seconds = (long)_config.SecondsPerCoin * Math.Max(0, gift.CoinCost) * amount;
        }

        if (seconds > 0)
            _clock.Add(TimeSpan.FromSeconds(seconds));

        var added = FormatDuration(seconds);
        var text = $"{gift.Username} envió {amount}x {gift.GiftName}  +{added}";

        _overlay.ShowGift(text);
        AppendLog($"REGALO: {text} ({gift.CoinCost} monedas c/u)");
    }

    private static string FormatDuration(long seconds)
    {
        if (seconds <= 0)
            return "0s";

        var t = TimeSpan.FromSeconds(seconds);

        if (t.TotalHours >= 1)
            return $"{(long)t.TotalHours}h {t.Minutes}m {t.Seconds}s";
        if (t.TotalMinutes >= 1)
            return $"{(long)t.TotalMinutes}m {t.Seconds}s";

        return $"{t.Seconds}s";
    }

    private void ToggleOverlay()
    {
        if (_overlayVisible)
        {
            _overlay.Hide();
            _overlayVisible = false;
            _btnOverlay.Text = "Mostrar Overlay";
        }
        else
        {
            _overlay.ApplyPosition(
                _cmbOverlayPosition.SelectedIndex == 1
                    ? OverlayPosition.TopRight
                    : OverlayPosition.TopLeft);

            _overlay.Show();
            _overlayVisible = true;
            _btnOverlay.Text = "Ocultar Overlay";
        }
    }

    private void SaveUiToConfig()
    {
        _config.TikTokRtmpUrl = _txtTikTokUrl.Text.Trim();
        _config.TikTokStreamKey = _txtTikTokKey.Text.Trim();
        _config.YouTubeRtmpUrl = _txtYouTubeUrl.Text.Trim();
        _config.YouTubeStreamKey = _txtYouTubeKey.Text.Trim();
        _config.TikTokUsername = _txtTikTokUser.Text.Trim();

        _config.Encoder = _cmbEncoder.SelectedIndex == 1
            ? EncoderMode.CpuX264
            : EncoderMode.IntelQsv;

        _config.OverlayPosition = _cmbOverlayPosition.SelectedIndex == 1
            ? OverlayPosition.TopRight
            : OverlayPosition.TopLeft;

        _config.SecondsPerCoin = (int)_numSecondsPerCoin.Value;

        var rules = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);

        foreach (DataGridViewRow row in _giftRules.Rows)
        {
            if (row.IsNewRow)
                continue;

            var name = Convert.ToString(row.Cells[0].Value)?.Trim();
            var secondsRaw = Convert.ToString(row.Cells[1].Value)?.Trim();

            if (string.IsNullOrWhiteSpace(name))
                continue;

            if (!int.TryParse(secondsRaw, out var seconds) || seconds < 0)
                continue;

            rules[name] = seconds;
        }

        _config.GiftRules = rules;

        try
        {
            _config.Save();
        }
        catch (Exception ex)
        {
            AppendLog("No se pudo guardar config.json: " + ex.Message);
        }
    }

    private void MarkConfigDirty()
    {
        _configDebounce.Stop();
        _configDebounce.Start();
    }

    private void RefreshPauseButton()
    {
        _btnPause.Text = _clock.IsPaused ? "Reanudar" : "Pausar";
    }

    private void AppendLog(string message)
    {
        SafeUi(() =>
        {
            var line = $"[{DateTime.Now:HH:mm:ss}] {message}";
            _logs.Items.Insert(0, line);

            while (_logs.Items.Count > 300)
                _logs.Items.RemoveAt(_logs.Items.Count - 1);
        });
    }

    private void SafeUi(Action action)
    {
        if (IsDisposed || Disposing)
            return;

        if (InvokeRequired)
        {
            try { BeginInvoke(action); } catch { }
        }
        else
        {
            action();
        }
    }

    private async void MainFormOnFormClosing(object? sender, FormClosingEventArgs e)
    {
        e.Cancel = true;
        Enabled = false;

        try
        {
            SaveUiToConfig();
            _clock.Save();

            _tikTokCts?.Cancel();

            if (_tikTokTask is not null)
            {
                try
                {
                    await Task.WhenAny(_tikTokTask, Task.Delay(1000));
                }
                catch
                {
                    // ignored
                }
            }

            await _streaming.StopAsync();

            _overlay.Close();
            _tikTok.Dispose();
        }
        finally
        {
            FormClosing -= MainFormOnFormClosing;
            e.Cancel = false;
            Close();
        }
    }
}
