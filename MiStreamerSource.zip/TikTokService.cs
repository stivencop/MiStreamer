using TikTokLiveSharp.Client;
using TikTokLiveSharp.Events;

namespace MiStreamer;

public sealed record TikTokGift(
    string Username,
    string GiftName,
    long Amount,
    int CoinCost);

public sealed class TikTokService : IDisposable
{
    private TikTokLiveClient? _client;

    public event Action? Connected;
    public event Action? Disconnected;
    public event Action<string, string>? ChatReceived;
    public event Action<TikTokGift>? GiftReceived;
    public event Action<string>? Log;

    public async Task RunAsync(string username, CancellationToken cancellationToken)
    {
        username = username.Trim().TrimStart('@');
        if (string.IsNullOrWhiteSpace(username))
            throw new ArgumentException("Debes escribir el usuario de TikTok.");

        _client = new TikTokLiveClient(username, "");

        _client.OnConnected += OnConnected;
        _client.OnDisconnected += OnDisconnected;
        _client.OnChatMessage += OnChatMessage;
        _client.OnGiftMessage += OnGiftMessage;

        Log?.Invoke($"Conectando al LIVE de @{username}...");

        try
        {
            await _client.RunAsync(cancellationToken);
        }
        catch (OperationCanceledException)
        {
            // Cierre solicitado por el usuario.
        }
        finally
        {
            Detach();
        }
    }

    private void OnConnected(TikTokLiveClient sender, bool connected)
    {
        Log?.Invoke(connected ? "TikTok LIVE conectado." : "TikTok respondió sin estado conectado.");
        Connected?.Invoke();
    }

    private void OnDisconnected(TikTokLiveClient sender, bool connected)
    {
        Log?.Invoke("TikTok LIVE desconectado.");
        Disconnected?.Invoke();
    }

    private void OnChatMessage(TikTokLiveClient sender, Chat e)
    {
        var username = e.Sender?.UniqueId ?? "usuario";
        ChatReceived?.Invoke(username, e.Message ?? "");
    }

    private void OnGiftMessage(TikTokLiveClient sender, GiftMessage e)
    {
        if (e.Gift is null)
            return;

        // TikTok emite eventos intermedios durante un streak.
        // Solo procesamos el final para no sumar el mismo regalo varias veces.
        if (e.Gift.IsStreakable && !e.StreakEnd)
            return;

        var amount = Math.Max(1L, e.Amount);
        var username = e.User?.UniqueId ?? "usuario";
        var name = string.IsNullOrWhiteSpace(e.Gift.Name) ? $"Gift #{e.GiftId}" : e.Gift.Name;
        var coinCost = Math.Max(0, e.Gift.DiamondCost);

        GiftReceived?.Invoke(new TikTokGift(username, name, amount, coinCost));
    }

    private void Detach()
    {
        if (_client is null)
            return;

        _client.OnConnected -= OnConnected;
        _client.OnDisconnected -= OnDisconnected;
        _client.OnChatMessage -= OnChatMessage;
        _client.OnGiftMessage -= OnGiftMessage;
        _client = null;
    }

    public void Dispose() => Detach();
}
