using System.Diagnostics;
using System.Globalization;
using System.Threading.Channels;
using NAudio.Wave;

namespace MiStreamer;

public sealed class StreamingService : IAsyncDisposable
{
    private Process? _ffmpeg;
    private WasapiLoopbackCapture? _loopback;
    private Channel<byte[]>? _audioChannel;
    private Task? _audioWriterTask;
    private Task? _stderrTask;

    private DateTime _lastMetricsAt = DateTime.UtcNow;
    private TimeSpan _lastCpu = TimeSpan.Zero;

    public event Action<string>? Log;

    public bool IsRunning => _ffmpeg is { HasExited: false };

    public async Task StartAsync(StreamerConfig config)
    {
        if (IsRunning)
            throw new InvalidOperationException("FFmpeg ya está ejecutándose.");

        if (!File.Exists(AppFiles.FfmpegPath))
            throw new FileNotFoundException("No se encontró ffmpeg.exe junto a MiStreamer.exe.", AppFiles.FfmpegPath);

        var outputs = new List<string>();

        AddOutput(outputs, config.TikTokRtmpUrl, config.TikTokStreamKey);
        AddOutput(outputs, config.YouTubeRtmpUrl, config.YouTubeStreamKey);

        if (outputs.Count == 0)
            throw new InvalidOperationException("Configura al menos un destino RTMP.");

        _loopback = new WasapiLoopbackCapture();
        var format = _loopback.WaveFormat;

        if (format.Encoding != WaveFormatEncoding.IeeeFloat || format.BitsPerSample != 32)
        {
            _loopback.Dispose();
            _loopback = null;
            throw new NotSupportedException(
                $"El audio de Windows usa un formato inesperado: {format}. " +
                "MiStreamer esperaba WASAPI Float32.");
        }

        var psi = new ProcessStartInfo
        {
            FileName = AppFiles.FfmpegPath,
            WorkingDirectory = AppFiles.BaseDirectory,
            UseShellExecute = false,
            CreateNoWindow = true,
            RedirectStandardInput = true,
            RedirectStandardError = true,
            RedirectStandardOutput = false
        };

        AddArguments(psi, config, format, outputs);

        _ffmpeg = new Process
        {
            StartInfo = psi,
            EnableRaisingEvents = true
        };

        _ffmpeg.Exited += (_, _) =>
        {
            try
            {
                Log?.Invoke($"FFmpeg finalizó. Código: {_ffmpeg?.ExitCode}");
            }
            catch
            {
                Log?.Invoke("FFmpeg finalizó.");
            }
        };

        if (!_ffmpeg.Start())
            throw new InvalidOperationException("No fue posible iniciar FFmpeg.");

        try
        {
            _ffmpeg.PriorityClass = ProcessPriorityClass.BelowNormal;
        }
        catch (Exception ex)
        {
            Log?.Invoke($"No fue posible fijar prioridad BelowNormal: {ex.Message}");
        }

        _audioChannel = Channel.CreateBounded<byte[]>(new BoundedChannelOptions(64)
        {
            SingleReader = true,
            SingleWriter = false,
            FullMode = BoundedChannelFullMode.DropOldest
        });

        _audioWriterTask = WriteAudioAsync(_ffmpeg, _audioChannel.Reader);
        _stderrTask = ReadStderrAsync(_ffmpeg);

        _loopback.DataAvailable += LoopbackOnDataAvailable;
        _loopback.RecordingStopped += (_, e) =>
        {
            if (e.Exception is not null)
                Log?.Invoke($"WASAPI se detuvo: {e.Exception.Message}");
        };

        _loopback.StartRecording();

        _lastMetricsAt = DateTime.UtcNow;
        _lastCpu = TimeSpan.Zero;

        Log?.Invoke(
            $"Streaming iniciado: 720x1280/30 FPS, audio WASAPI loopback {format.SampleRate} Hz, " +
            $"{format.Channels} canales, prioridad FFmpeg BelowNormal.");

        await Task.CompletedTask;
    }

    public async Task StopAsync()
    {
        var process = _ffmpeg;

        if (_loopback is not null)
        {
            try
            {
                _loopback.StopRecording();
            }
            catch
            {
                // ignored
            }

            _loopback.DataAvailable -= LoopbackOnDataAvailable;
            _loopback.Dispose();
            _loopback = null;
        }

        _audioChannel?.Writer.TryComplete();

        if (process is not null)
        {
            try
            {
                // Cerrar el pipe desbloquea cualquier escritura pendiente del capturador.
                process.StandardInput.Close();
            }
            catch
            {
                // ignored
            }
        }

        if (_audioWriterTask is not null)
        {
            try { await _audioWriterTask; } catch { }
            _audioWriterTask = null;
        }

        if (process is not null)
        {
            if (!process.HasExited)
            {
                using var timeout = new CancellationTokenSource(TimeSpan.FromSeconds(3));

                try
                {
                    await process.WaitForExitAsync(timeout.Token);
                }
                catch (OperationCanceledException)
                {
                    try { process.Kill(entireProcessTree: true); } catch { }
                }
            }

            process.Dispose();
        }

        _ffmpeg = null;
        _audioChannel = null;

        if (_stderrTask is not null)
        {
            try { await _stderrTask; } catch { }
            _stderrTask = null;
        }

        Log?.Invoke("Streaming detenido.");
    }

    public string GetMetrics()
    {
        var process = _ffmpeg;
        if (process is null || process.HasExited)
            return "FFmpeg: detenido";

        try
        {
            process.Refresh();

            var now = DateTime.UtcNow;
            var cpuNow = process.TotalProcessorTime;
            var elapsed = now - _lastMetricsAt;
            var cpuDelta = cpuNow - _lastCpu;

            var cpu = elapsed.TotalMilliseconds <= 0
                ? 0
                : cpuDelta.TotalMilliseconds /
                  (elapsed.TotalMilliseconds * Environment.ProcessorCount) * 100.0;

            _lastMetricsAt = now;
            _lastCpu = cpuNow;

            var ramMb = process.WorkingSet64 / 1024d / 1024d;

            return $"FFmpeg: {ramMb:0.0} MB | CPU: {Math.Clamp(cpu, 0, 100):0.0}%";
        }
        catch
        {
            return "FFmpeg: ejecutándose";
        }
    }

    private void LoopbackOnDataAvailable(object? sender, WaveInEventArgs e)
    {
        if (_audioChannel is null || e.BytesRecorded <= 0)
            return;

        var copy = new byte[e.BytesRecorded];
        Buffer.BlockCopy(e.Buffer, 0, copy, 0, e.BytesRecorded);
        _audioChannel.Writer.TryWrite(copy);
    }

    private static async Task WriteAudioAsync(Process process, ChannelReader<byte[]> reader)
    {
        try
        {
            await foreach (var block in reader.ReadAllAsync())
            {
                await process.StandardInput.BaseStream.WriteAsync(block);
            }

            await process.StandardInput.BaseStream.FlushAsync();
        }
        catch
        {
            // FFmpeg cerrado o pipe terminado.
        }
    }

    private async Task ReadStderrAsync(Process process)
    {
        try
        {
            while (!process.HasExited)
            {
                var line = await process.StandardError.ReadLineAsync();
                if (line is null)
                    break;

                if (line.Contains("error", StringComparison.OrdinalIgnoreCase) ||
                    line.Contains("failed", StringComparison.OrdinalIgnoreCase) ||
                    line.Contains("warning", StringComparison.OrdinalIgnoreCase))
                {
                    Log?.Invoke("FFmpeg: " + line);
                }
            }
        }
        catch
        {
            // ignored
        }
    }

    private static void AddOutput(List<string> outputs, string url, string key)
    {
        url = url.Trim();
        key = key.Trim();

        if (string.IsNullOrWhiteSpace(url) || string.IsNullOrWhiteSpace(key))
            return;

        var endpoint = url.TrimEnd('/') + "/" + key.TrimStart('/');
        outputs.Add($"[f=flv:onfail=ignore]{EscapeTeeUrl(endpoint)}");
    }

    private static string EscapeTeeUrl(string url) =>
        url.Replace("\\", "\\\\", StringComparison.Ordinal)
           .Replace("|", "\\|", StringComparison.Ordinal);

    private static void AddArguments(
        ProcessStartInfo psi,
        StreamerConfig config,
        WaveFormat audio,
        IReadOnlyList<string> outputs)
    {
        static void A(ProcessStartInfo p, params string[] args)
        {
            foreach (var arg in args)
                p.ArgumentList.Add(arg);
        }

        A(psi,
            "-hide_banner",
            "-loglevel", "info",
            "-thread_queue_size", "512",
            "-f", "gdigrab",
            "-framerate", "30",
            "-draw_mouse", "1",
            "-i", "desktop",
            "-thread_queue_size", "512",
            "-f", "f32le",
            "-ar", audio.SampleRate.ToString(CultureInfo.InvariantCulture),
            "-ac", audio.Channels.ToString(CultureInfo.InvariantCulture),
            "-i", "pipe:0",
            "-map", "0:v:0",
            "-map", "1:a:0",
            "-vf", "scale=-2:1280,crop=720:1280",
            "-r", "30");

        if (config.Encoder == EncoderMode.IntelQsv)
        {
            A(psi,
                "-c:v", "h264_qsv",
                "-preset", "veryfast",
                "-b:v", "2500k",
                "-maxrate", "2500k",
                "-bufsize", "5000k",
                "-g", "60",
                "-pix_fmt", "nv12");
        }
        else
        {
            A(psi,
                "-c:v", "libx264",
                "-preset", "ultrafast",
                "-tune", "zerolatency",
                "-threads", "2",
                "-b:v", "2000k",
                "-maxrate", "2000k",
                "-bufsize", "4000k",
                "-g", "60",
                "-pix_fmt", "yuv420p");
        }

        A(psi,
            "-c:a", "aac",
            "-b:a", "128k",
            "-ar", "44100",
            "-ac", "2",
            "-flags", "+global_header",
            "-f", "tee",
            string.Join("|", outputs));
    }

    public async ValueTask DisposeAsync()
    {
        await StopAsync();
    }
}
