# MiStreamer

Aplicación WinForms .NET 8 para streaming vertical 720x1280/30 FPS con:

- FFmpeg como subproceso.
- Intel QSV o x264 ultrafast / 2 threads.
- Dual stream RTMP mediante muxer `tee`.
- Captura de escritorio con `gdigrab`.
- Audio del sistema con **WASAPI Loopback usando NAudio**, enviado a FFmpeg por `pipe:0`.
- Overlay Win32 TopMost + Click-Through + NoActivate.
- Cronómetro extensible persistente.
- Reglas de regalos TikTok.
- TikTokLiveSharp (`TikTokLive_Sharp`).

## Por qué el audio no usa `-f wasapi -i default`

FFmpeg mainline para Windows no ofrece un input WASAPI estándar equivalente a ese comando.
Para mantener captura real del audio del sistema sin instalar un driver virtual,
MiStreamer usa `WasapiLoopbackCapture` de NAudio y alimenta PCM Float32 a FFmpeg.

## Archivos generados

Al ejecutar por primera vez:

- `config.json`
- `tiempo_extensible.txt`

Deben permanecer junto a `MiStreamer.exe`.

## FFmpeg

El workflow de GitHub descarga automáticamente un build Windows de FFmpeg
y coloca `ffmpeg.exe` junto a `MiStreamer.exe`.

## Compilación

El workflow `.github/workflows/build-windows.yml` publica:

`MiStreamer-Windows-x64.zip`

en la sección **Actions > Artifacts**.

## Nota TikTok

TikTokLiveSharp es una biblioteca comunitaria basada en ingeniería inversa.
TikTok puede cambiar su protocolo sin previo aviso. El streaming, overlay y
cronómetro están separados de esa conexión para que sigan funcionando aunque
la conexión de chat falle.
